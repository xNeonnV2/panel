import os, colorama
print ("""
                                             

\x1b[38;5;196m   .dMMMb  dMMMMMP dMMMMMMP dMP dMP dMMMMb 
  dMP" VP dMP        dMP   dMP dMP dMP.dMP 
  VMMMb  dMMMP      dMP   dMP dMP dMMMMP"  
dP .dMP dMP        dMP   dMP.aMP dMP       
VMMMP" dMMMMMP    dMP    VMMMP" dMP\x1b[38;5;255m        
                                           

""")
print("""\x1b[38;5;196m[\x1b[38;5;255m1\x1b[38;5;196m] \x1b[38;5;255mSetup & Install Module\n\x1b[38;5;196m[\x1b[38;5;255m2\x1b[38;5;196m] \x1b[38;5;255mCancel & Exit Tool\n=============================""")
c = input("►► ")
if c == "1":
    os.system("npm install gradient-string")
    os.system("npm install path")
    os.system("apt upgrade -y")
    os.system("apt install screen -y")
    os.system("apt update -y")
    os.system("npm install cheerio")
    os.system("npm install axios")
    os.system("npm install header-generator")
    os.system("npm install randomstring")
    os.system("npm install request")
    os.system("npm install fake-useragent")
    os.system("npm install user-agents")
    os.system("npm install net")
    os.system("npm install cloudscraper")
    os.system("npm install crypto")
    os.system("pip install socket")
    os.system("pip install random")
    os.system("pip install string")
    os.system("pip install threading")
    os.system("pip install getpass")
    os.system("pip install urllib")
    os.system("pip install colorama")
    os.system("pip install os")
    os.system("pip install sys")
    os.system("pip install time")
    os.system("pip install re")
    os.system("pip install requests")
    os.system("pip install json")
    os.system("pip install codecs")
    os.system("pip install datetime")
    os.system("chmod 777 *")
    os.system("clear")
    print ("Đã Tải Xong Các Module!\nDùng Lệnh Sau Để Vào Tool:\n>>> python main.py")

elif c == "2":
    os.system("clear")
print ("Goodbye!")    