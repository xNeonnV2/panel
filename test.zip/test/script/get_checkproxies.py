import sys
import socket
import requests
import concurrent.futures

def check_http_https_proxy(proxy):
    try:
        socket.setdefaulttimeout(3)
        host, port = proxy.split(':')
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, int(port)))
        return True
    except:
        pass
    return False    

def remove_dead_proxies(input_file):
    with open(input_file, 'r') as file:
        proxies = file.readlines()

    alive_proxies = []
    proxy_count = len(proxies)
    live_proxy_count = 0
    die_proxy_count = 0

    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = []
        for proxy in proxies:
            future = executor.submit(check_http_https_proxy, proxy.strip())
            futures.append((proxy.strip(), future))

        for proxy, future in futures:
            if future.result():
                alive_proxies.append(proxy)
                live_proxy_count += 1
                print(f'| Live \x1b[38;5;255m| \x1b[38;5;119m{proxy}\x1b[38;5;255m')
            else:
                print(f'| \x1b[38;5;196mDie \x1b[38;5;255m | \x1b[38;5;196m{proxy}\x1b[38;5;255m')
                if remove_proxy(proxy, input_file):
                    die_proxy_count += 1

    with open(input_file, 'w') as file:
        file.write('\n'.join(alive_proxies))

    print(f'\n\x1b[38;5;226mTotal \x1b[38;5;255m{proxy_count} > \x1b[38;5;119mLive\x1b[38;5;255m/\x1b[38;5;196mDie \x1b[38;5;255m(\x1b[38;5;119m{live_proxy_count}\x1b[38;5;255m/\x1b[38;5;196m{die_proxy_count}\x1b[38;5;255m)')

def remove_proxy(proxy, input_file):
    try:
        with open(input_file, 'r') as file:
            proxies = file.readlines()

        with open(input_file, 'w') as file:
            for line in proxies:
                if line.strip() != proxy:
                    file.write(line)

        return True
    except:
        return False

def get_proxies_from_api(api_url):
    try:
        response = requests.get(api_url)
        if response.status_code == 200:
            return [proxy.strip() for proxy in response.text.split('\n')]
    except:
        pass

    return []

print("Proxies Checker Tool - xNeonn")
print("\x1b[38;5;226mYour IP:\x1b[38;5;255m", requests.get("https://api.ipify.org").text)
print("\n\n")

# Lấy đối số dòng lệnh là tên file cần check
input_file = "proxy.txt"
proxy_sources = {
    "HTTP/S": [
            "https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/HTTP.txt",
            "https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/http.txt",
            "https://raw.githubusercontent.com/HyperBeats/proxy-list/main/http.txt",
            "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
            "https://api.proxyscrape.com/?request=displayproxies&proxytype=http",
            "https://api.openproxylist.xyz/http.txt",
            "http://alexa.lr2b.com/proxylist.txt",
            "https://multiproxy.org/txt_all/proxy.txt",
            "https://proxyspace.pro/http.txt",
            "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
            "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/http.txt",
            "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
            "https://raw.githubusercontent.com/shiftytr/proxy-list/master/proxy.txt",
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
            "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
            "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
            "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
            "https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt",
            "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
            "https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt",
            "https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt",
            "http://rootjazz.com/proxies/proxies.txt",
            "http://spys.me/proxy.txt",
            "https://proxyspace.pro/http.txt",
            "https://www.proxy-list.download/api/v1/get?type=http",
            "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt",
            "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies_anonymous/http.txt",
            "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/http.txt",
            "https://sunny9577.github.io/proxy-scraper/proxies.txt",
            "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt",
            "https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt",
            "https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt",
            "https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt",
            "http://sslproxies.org",
            "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-https.txt",
            "https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/https.txt",
            "https://raw.githubusercontent.com/HyperBeats/proxy-list/main/https.txt",
            "https://proxyspace.pro/https.txt",
    ],
}

for protocol, sources in proxy_sources.items():
    print(f"\nGetting {protocol} Proxies:")
    for source in sources:
        print(f"\x1b[38;5;196m[\x1b[38;5;255mScraping Proxy\x1b[38;5;196m] \x1b[38;5;255m {source}")
        proxies = get_proxies_from_api(source)
        with open(input_file, 'a') as file:
            file.write('\n'.join(proxies) + '\n')

remove_dead_proxies(input_file)

print("\n\x1b[38;5;226m Proxies Check Completed.")